/**
 * 
 */
/**
 * 
 */
module GameDevJava {
	requires java.desktop;
}